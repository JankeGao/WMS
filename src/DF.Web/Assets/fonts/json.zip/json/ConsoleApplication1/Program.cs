﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Hcf.Utility;
using Hcf.Utility.Files;
using HtmlAgilityPack;
using Hcf.Utility.Extensions;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            var doc = new HtmlDocument();
            StreamReader sr = File.OpenText("../../html.txt");
            doc.Load(sr);

            List<HtmlNode> nodes = new List<HtmlNode>()
            {
                doc.GetElementbyId("web-application"),
                doc.GetElementbyId("accessibility"),
                doc.GetElementbyId("hand"),
                doc.GetElementbyId("transportation"),
                doc.GetElementbyId("gender"),
                doc.GetElementbyId("file-type"),
                doc.GetElementbyId("spinner"),
                doc.GetElementbyId("form-control"),
                doc.GetElementbyId("payment"),
                doc.GetElementbyId("chart"),
                doc.GetElementbyId("currency"),
                doc.GetElementbyId("text-editor"),
                doc.GetElementbyId("directional"),
                doc.GetElementbyId("video-player"),
                doc.GetElementbyId("brand"),
                doc.GetElementbyId("medical")
            };

            List<string> result = new List<string>();
            foreach (HtmlNode node in nodes)
            {
                foreach (var div in node.Element("div").Elements("div"))
                {
                    var cls = div.Element("a").Element("i").Attributes["class"].Value;
                    if (!string.IsNullOrEmpty(cls)&&!result.Contains(cls))
                    {
                        cls = cls.Substring(6);
                        result.Add(cls);
                    }
                }
            }

            FileHelper.Write("d://icons.json", JsonHelper.SerializeObject(result));
        }

    }
}
